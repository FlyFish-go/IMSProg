#!/usr/bin/env bash
# Rebuild the source-modified libusb 1.0.30 x64 runtime with MinGW-w64 GCC.
# Requires gcc, windres, and strip from a MinGW-w64 x86_64 toolchain.
set -euo pipefail
cd "$(dirname "$0")"
TC_PREFIX=${TC_PREFIX:-x86_64-w64-mingw32-}
CC=${CC:-${TC_PREFIX}gcc}
WINDRES=${WINDRES:-${TC_PREFIX}windres}
STRIP=${STRIP:-${TC_PREFIX}strip}
mkdir -p build
cp imsprog-config.h build/config.h
"$WINDRES" --preprocessor="$CC" --preprocessor-arg=-E --preprocessor-arg=-xc --preprocessor-arg=-DRC_INVOKED -Ilibusb -i libusb/libusb-1.0.rc -o build/libusb-1.0-resource.o
"$CC" -Ibuild -Ilibusb -O2 -std=gnu11 -DNDEBUG -shared -static-libgcc \
 libusb/core.c libusb/descriptor.c libusb/hotplug.c libusb/io.c libusb/strerror.c libusb/sync.c \
 libusb/os/events_windows.c libusb/os/threads_windows.c libusb/os/windows_common.c \
 libusb/os/windows_usbdk.c libusb/os/windows_winusb.c libusb/libusb-1.0.def \
 build/libusb-1.0-resource.o -Wl,--out-implib,build/libusb-1.0.dll.a \
 -Wl,--kill-at -Wl,--no-insert-timestamp -o build/libusb-1.0.dll
"$STRIP" --strip-unneeded build/libusb-1.0.dll
